import os
import time

from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import change_language
from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.driver.loc_driver import LocDriver
from SpecialTestSubject.GandalfLanguage.base.recording import AndroidRecording
from SpecialTestSubject.GandalfLanguage.testcase.base import Base


class TestInstallationFlow(Base):

    def setup(self):
        base = Base()
        self.vb_cmd_driver = CmdDriver(base.vb8250_udid)
        self.vb_loc_driver = LocDriver(base.vb8250_udid)
        lang = os.getenv("Current_Language")
        change_language(lang, Base().vb8250_udid, function="vb_installation",close_page=True)
        cmd_driver = CmdDriver()
        cmd_driver.exec_pcos_cmd("taskkill -f /IM chrome.exe")
        self.vb_androidRecording = AndroidRecording(base.vb8250_udid)

        # Choose language
        self.vb_androidRecording.android_start_recording()

    def teardown(self):
        self.vb_androidRecording.android_stop_recording("test_loc_vb_and_tc_mode_installation_flow")

    def test_loc_vb_standalone_installation_flow(self, language):
        print(language)
        # Choose language
        self.vb_loc_driver.loc_snapshot("01_Continue_on_this_device", "vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("01_Continue_on_this_device", "vb_installation_flow_page")

        # change_language(language, Base().vb8250_udid,True)
        self.vb_loc_driver.find_element_by_loc_text("Continue on this device",name="vb_installation_serviceprovider_continue_title_variant").click()
        time.sleep(8)
        self.vb_loc_driver.loc_snapshot("02_choose_language", "vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("02_choose_language", "vb_installation_flow_page")
        self.vb_loc_driver.find_element_by_loc_text("Next").click()


        # Read privacy policy
        time.sleep(8)
        self.vb_loc_driver.loc_snapshot("03_privacy_policy", "vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("03_privacy_policy", "vb_installation_flow_page")
        self.vb_loc_driver.find_element_by_loc_text("Accept").click()

        # Read license agreement
        x = self.vb_loc_driver.get_screen_size()[0] / 2
        y1 = self.vb_loc_driver.get_screen_size()[1] / 5
        y2 = self.vb_loc_driver.get_screen_size()[1] / 1.5
        for i in range(5):
            self.vb_cmd_driver.exec_adb_shell_cmd(f"input swipe {x} {y2} {x} {y1}")
        self.vb_loc_driver.loc_snapshot("04_license_agreement", "vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("04_license_agreement", "vb_installation_flow_page")
        self.vb_loc_driver.find_element_by_loc_text("Accept").click()
        time.sleep(3)

        # get data and time
        self.vb_loc_driver.loc_snapshot("05_data_and_time", "tc_vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("11_data_and_time", "tc_vb_installation_flow_page")
        try:
            self.vb_loc_driver.find_element_by_loc_text(text="Change",
                                                        name="tc_installation_date_adjust_button").click()
        except:
            self.vb_loc_driver.find_element_by_loc_text(text="Network settings",
                                                        name="tc_installation_date_adjust_button").click()
            self.vb_loc_driver.find_element_by_loc_text(text="Time Server (NTP)",
                                                        name="tc_installation_date_adjust_button").next_sibling().click()
            self.vb_loc_driver.find_element_by_loc_text(text="Time Server (NTP)",
                                                        name="tc_installation_date_adjust_button").next_sibling().set_text(
                "ntp1.aliyun.com")
            self.vb_loc_driver.find_element_by_loc_text(text="Save", name="tc_installation_date_adjust_button").click()
            # self.tc_loc_driver.find_element_by_loc_text(text="Close",
            # name="tc_installation_date_adjust_button").click()
            self.vb_loc_driver.find_element_by_loc_text(text="Change",
                                                        name="tc_installation_date_adjust_button").click()

        self.vb_loc_driver.find_element_by_loc_text(text="City or location").wait_for_appearance(40)
        self.vb_loc_driver.loc_snapshot("06_select_time_zoom", "tc_vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("06_select_time_zoom", "tc_vb_installation_flow_page")
        self.vb_loc_driver.find_element_by_loc_text(text="Back").click()
        self.vb_loc_driver.find_element_by_loc_text(text="Next").click()

        self.vb_loc_driver.loc_snapshot("07_Select_video_service_provider", "vb_installation_flow_page")
        self.vb_loc_driver.check_text_in_current_page("08_Select_video_service_provider", "vb_installation_flow_page")
