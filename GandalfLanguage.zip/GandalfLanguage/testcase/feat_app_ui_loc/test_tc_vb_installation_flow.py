import os
import time

from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import change_language
from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.driver.loc_driver import LocDriver
from SpecialTestSubject.GandalfLanguage.base.recording import AndroidRecording
from SpecialTestSubject.GandalfLanguage.testcase.base import Base


class TestInstallationFlow(Base):

    def setup(self):
        base = Base()
        self.tc_cmd_driver = CmdDriver(base.tc_udid)
        self.vb_loc_driver = LocDriver(base.vb8250_udid)
        self.tc_loc_driver = LocDriver(base.tc_udid)
        lang = os.getenv("Current_Language")
        change_language(lang, Base().tc_udid, function="tc_installation",close_page=True)
        change_language(lang, Base().vb8250_udid, function="vb_installation",close_page=True)
        cmd_driver = CmdDriver()
        cmd_driver.exec_pcos_cmd("taskkill -f /IM chrome.exe")
        self.tc_androidRecording = AndroidRecording(base.tc_udid)
        self.vb_androidRecording = AndroidRecording(base.vb8250_udid)


        # Choose language
        self.tc_androidRecording.android_start_recording()
        self.vb_androidRecording.android_start_recording()

    def teardown(self):
        self.tc_androidRecording.android_stop_recording("test_loc_vb_and_tc_mode_installation_flow")
        self.vb_androidRecording.android_stop_recording("test_loc_vb_and_tc_mode_installation_flow")

    def test_loc_vb_and_tc_mode_installation_flow(self, language):
        self.tc_loc_driver.find_element_by_loc_text("Next").click()
        self.tc_loc_driver.loc_snapshot("01_choose_language", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("01_choose_language", "tc_vb_installation_flow_page")
        self.tc_loc_driver.loc_snapshot("02_vb_init_page", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("01_choose_language", "tc_vb_installation_flow_page")

        # Read privacy policy
        self.tc_loc_driver.loc_snapshot("03_privacy_policy", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("03_privacy_policy", "tc_vb_installation_flow_page")
        self.tc_loc_driver.find_element_by_loc_text("Accept").click()

        # Read license agreement
        x = self.tc_loc_driver.get_screen_size()[0] / 2
        y1 = self.tc_loc_driver.get_screen_size()[1] / 5
        y2 = self.tc_loc_driver.get_screen_size()[1] / 1.5
        for i in range(3):
            self.tc_cmd_driver.exec_adb_shell_cmd(f"input swipe {x} {y2} {x} {y1}")
        self.tc_loc_driver.loc_snapshot("04_license_agreement", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("04_license_agreement", "tc_vb_installation_flow_page")
        self.tc_loc_driver.find_element_by_loc_text("Accept").click()
        self.tc_loc_driver.find_element_by_loc_text("Network established").wait_for_appearance()
        self.tc_loc_driver.loc_snapshot("05_establishing_network_connections", "tc_vb_installation_flow_page")
        self.tc_loc_driver.find_element_by_loc_text("Preparing list of video bars").wait_for_appearance()
        self.tc_loc_driver.loc_snapshot("06_Preparing_list_of_video_bars", "tc_vb_installation_flow_page")
        # Connect with a new device
        self.tc_loc_driver.find_element_by_loc_text(text="Available video bars")
        self.tc_loc_driver.loc_snapshot("07_connect_with_a_new_device", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("07_connect_with_a_new_device", "tc_vb_installation_flow_page")
        self.tc_loc_driver.find_element_by_loc_text(text="Refresh").click()
        self.tc_loc_driver.scroll_to_find_element(text=Base().vb8250_udid).next_sibling().click()
        self.tc_loc_driver.find_element_by_loc_text(text="Close", name="tc_settings_menu_side_menu_close_button",
                                                    timeout=20).click()

        # self.tc_loc_driver.find_element_by_loc_text("Paired with video bar").wait_for_appearance()
        # self.tc_loc_driver.loc_snapshot("08_paired_with_video_bar", "tc_vb_installation_flow_page")
        self.vb_loc_driver.find_element_by_loc_text("Paired with touch controller",name = "tc_installation_pairing_success_tc").wait_for_appearance()
        self.tc_loc_driver.loc_snapshot("09_vb_pair_with_tc", "tc_vb_installation_flow_page")

        # self.tc_loc_driver.find_element_by_loc_text("Please wait","tc_vb_installation_flow_page").wait_for_appearance()
        # self.tc_loc_driver.loc_snapshot("10_please wait", "tc_vb_installation_flow_page")

        # get data and time
        self.tc_loc_driver.loc_snapshot("10_data_and_time", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("11_data_and_time", "tc_vb_installation_flow_page")
        try:
            self.tc_loc_driver.find_element_by_loc_text(text="Change",
                                                        name="tc_installation_date_adjust_button").click()
        except:
            self.tc_loc_driver.find_element_by_loc_text(text="Network settings",
                                                        name="tc_installation_date_adjust_button").click()
            self.tc_loc_driver.find_element_by_loc_text(text="Time Server (NTP)",
                                                        name="tc_installation_date_adjust_button").next_sibling().click()
            self.tc_loc_driver.find_element_by_loc_text(text="Time Server (NTP)",
                                                        name="tc_installation_date_adjust_button").next_sibling().set_text(
                "ntp1.aliyun.com")
            self.tc_loc_driver.find_element_by_loc_text(text="Save", name="tc_installation_date_adjust_button").click()
            # self.tc_loc_driver.find_element_by_loc_text(text="Close", name="tc_installation_date_adjust_button").click()
            self.tc_loc_driver.find_element_by_loc_text(text="Change",
                                                        name="tc_installation_date_adjust_button").click()

        self.tc_loc_driver.find_element_by_loc_text(text="City or location").wait_for_appearance(40)
        self.tc_loc_driver.loc_snapshot("11_select_time_zoom", "tc_vb_installation_flow_page")
        self.tc_loc_driver.check_text_in_current_page("10_select_time_zoom", "tc_vb_installation_flow_page")
        self.tc_loc_driver.find_element_by_loc_text(text="Back").click()
        self.tc_loc_driver.find_element_by_loc_text(text="Next").click()
        time.sleep(1)
        # self.tc_loc_driver.find_element_by_loc_text("Checking system","tc_vb_installation_flow_page").wait_for_appearance()
        self.tc_loc_driver.loc_snapshot("12_checking_system", "tc_vb_installation_flow_page")
        time.sleep(10)
        self.tc_loc_driver.loc_snapshot("13_Select_video_service_provider", "tc_vb_installation_flow_page")
