import json
import os
import time
from distutils.util import strtobool

import pytest
from nico.nico import AdbAutoNico

from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import change_language
from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.driver.converting_strings import collect_error_info
from SpecialTestSubject.GandalfLanguage.base.driver.pcos_driver.pcos_driver import PcosDriver
from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger
from SpecialTestSubject.GandalfLanguage.base.driver.gnp_private_driver import GnpPrivateDriver
from SpecialTestSubject.GandalfLanguage.testcase.base import Base, Gandalf_TC


@pytest.fixture(scope="function", autouse=True)
def a_tc_factory_reset(request):
    currently_running_function = request.node.name.split("[")[0]
    if "installation_flow" in currently_running_function:
        gnp_ins = GnpPrivateDriver()
        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[GnpDriver] tc_factory_reset")
            assert gnp_ins.gnp_write(Base().tc_pid, Base().tc_udid, "01", "13", "11", ["00"])


@pytest.fixture(scope="function", autouse=True)
def b_vb_factory_reset(request):
    currently_running_function = request.node.name.split("[")[0]
    if "installation_flow" in currently_running_function:
        gnp_ins = GnpPrivateDriver()
        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[function] vb_factory_reset")
            assert gnp_ins.gnp_write(Base().vb8250_pid, Base().vb8250_udid, "01", "13", "11", ["00"])


@pytest.fixture(scope="function", autouse=True)
def c_wait_tc_ready(request):
    pcos_ins = PcosDriver()
    currently_running_function = request.node.name.split("[")[0]
    cmd_driver = CmdDriver(Base().tc_udid)
    if "installation_flow" in currently_running_function:
        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[function] wait_tc_ready")
            pcos_ins.wait_android_device_connected(Base().tc_pid, Base().tc_vid, 120)
            cmd_driver.exec_adb_cmd_wait_output(r"logcat -d -b events| grep boot_progress_enable_screen", 200)
            Logger.ins().file_logger().info("--->[function] tc already")
            clear_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -s ''"]
            cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
            time.sleep(10)
    AdbAutoNico(Base().tc_udid)


@pytest.fixture(scope="function", autouse=True)
def d_wait_vb_ready(request):
    pcos_ins = PcosDriver()
    cmd_driver = CmdDriver(Base().vb8250_udid)
    currently_running_function = request.node.name.split("[")[0]
    if "installation_flow" in currently_running_function:

        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[function] wait_vb_ready")
            pcos_ins.wait_android_device_connected(Base().vb8250_pid, Base().vb8250_vid, 90)
            cmd_driver.exec_adb_cmd_wait_output(r"logcat -d -b events| grep boot_progress_enable_screen", 200)
            Logger.ins().file_logger().info("--->[function] vb already")
            clear_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -s ''"]
            cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
            time.sleep(10)
    AdbAutoNico(Base().vb8250_udid)


@pytest.fixture(scope="function")
def change_tc_vb_language():
    lang = os.getenv("Current_Language")
    change_language(lang, Base().vb8250_udid)
    change_language(lang, Base().tc_udid)


def pytest_generate_tests(metafunc):
    if "language" in metafunc.fixturenames:
        env_conf_path = r"%s\languages.json" % (os.path.dirname(__file__))
        with open(env_conf_path) as f:
            data = json.load(f)
        metafunc.parametrize("language", data.get("languages"))


def pytest_runtest_protocol(item):
    language = item.callspec.params.get("language")
    if language:
        os.environ["Current_Language"] = language
        os.environ[
            "Current_Languages_File_Path"] = r"C:\plt--vendor--jabra--packages--apps--jabra-meeting-android\app\src\main\res"

    return None


@pytest.fixture(scope="session", autouse=True)
def test3():
    yield
    collect_error_info()


@pytest.fixture(scope="function")
def set_pre_vass_as_zoom(request):
    driver = request.param
    udid = Base().tc_udid if driver == Gandalf_TC else Base().vb8250_udid
    cmd_driver = CmdDriver(udid)
    set_pre_vass_cmds = ["cd system/vendor/bin",
                         "./jose_service_controller storage -w preselected.vaasprovider:string:ZOOM"]
    check_pre_vass_cmds = ["cd system/vendor/bin", "./jose_service_controller storage -r preselected.vaasprovider"]

    assert cmd_driver.exec_adb_shell_cmd(set_pre_vass_cmds)
    assert cmd_driver.exec_adb_shell_cmd(check_pre_vass_cmds).find(
        "ZOOM") > 0, "#pre_condition check pre-vass as Zoom fail"


@pytest.fixture(scope="function")
def set_pre_pair(request):
    driver = request.param
    udid = Base().tc_udid if driver == Gandalf_TC else Base().vb8250_udid
    another_udid = Base().vb8250_udid if driver == Gandalf_TC else Base().tc_udid
    cmd_driver = CmdDriver(udid)

    set_pre_pair_cmds = ["cd system/vendor/bin", f"./jose_service_controller device -s {another_udid}' '"]
    assert cmd_driver.exec_adb_shell_cmd(set_pre_pair_cmds), "#pre_condition set pre-pair fail"
    check_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -d"]

    assert cmd_driver.exec_adb_shell_cmd(check_pre_pair_cmds).find(
        another_udid) > 0, "#pre_condition check pre-pair serial number fail"
    yield
    clear_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -s ' '"]
    assert cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
