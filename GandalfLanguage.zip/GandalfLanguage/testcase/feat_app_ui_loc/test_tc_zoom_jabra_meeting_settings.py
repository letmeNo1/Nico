import os
import time

from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import change_language
from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.driver.loc_driver import LocDriver
from SpecialTestSubject.GandalfLanguage.base.recording import AndroidRecording
from SpecialTestSubject.GandalfLanguage.testcase.base import Base


class TestTeamsJabraMeetingSettings(Base):

    def setup(self):
        base = Base()
        lang = os.getenv("Current_Language")
        change_language(lang, Base().vb8250_udid,function="jabra_meeting")
        change_language(lang, Base().tc_udid,function="jabra_meeting")
        self.tc_loc_driver = LocDriver(base.tc_udid)
        self.tc_cmd_driver = CmdDriver(base.tc_udid)
        os.system(
            f'''adb -s {base.tc_udid} shell "am start -n com.gn.joseapiexample/com.gn.joseapiexample.MainActivity"''')
        self.tc_loc_driver.scroll_to_find_element(id="com.gn.joseapiexample:id/spnVaasProvider").click()
        self.tc_loc_driver.nico(id="android:id/text1", text="ZOOM").wait_for_appearance()
        self.tc_loc_driver.nico(id="android:id/text1", text="ZOOM").click()
        self.tc_loc_driver.nico(id="com.gn.joseapiexample:id/btnSetVaasProvider").click()
        self.tc_loc_driver.nico(id="com.gn.joseapiexample:id/btnLaunchVaasServices").click()
        self.x = self.tc_loc_driver.get_screen_size()[0] / 2
        self.y1 = self.tc_loc_driver.get_screen_size()[1] / 5
        self.y2 = self.tc_loc_driver.get_screen_size()[1] / 1.5

        self.tc_androidRecording = AndroidRecording(base.tc_udid)
        self.tc_androidRecording.android_start_recording()

    def teardown(self):
        self.tc_androidRecording.android_stop_recording("test_tc_teams_jabra_meeting_settings")

    def test_tc_zoom_jabra_meeting_settings(self, language):
        self.tc_loc_driver.loc_snapshot("00_Zoom_Ready", "vb_zoom_jabra_meeting_setting", 2)
        time.sleep(5)

        if self.tc_loc_driver.nico(id="us.zoom.zrc:id/system_settings").exists():
            self.tc_loc_driver.nico(id="us.zoom.zrc:id/system_settings").click()
        else:
            self.tc_loc_driver.nico(id="us.zoom.zrc:id/pt_settings").wait_for_appearance(3)
            self.tc_loc_driver.nico(id="us.zoom.zrc:id/pt_settings").click()
            self.tc_loc_driver.nico(id="us.zoom.zrc:id/system_settings").wait_for_appearance()
            self.tc_loc_driver.nico(id="us.zoom.zrc:id/system_settings").click()

        self.tc_loc_driver.find_element_by_loc_text("Room name").wait_for_appearance()
        self.tc_loc_driver.loc_snapshot("02_About_Devices", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("02_About_Devices", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Room name").wait_for_appearance()
        self.tc_loc_driver.find_element_by_loc_text("Support", name="tc_settings_menu_general_support").click()
        self.tc_loc_driver.find_element_by_loc_text("Phone").wait_for_appearance()

        # check system
        self.tc_loc_driver.nico(class_name="android.widget.Button").get(1).click()
        self.tc_loc_driver.loc_snapshot("06_System_System_management", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("06_System_System_management", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Firmware download site/URL").next_sibling().click()
        self.tc_loc_driver.check_text_in_current_page("06_System_System_management_firmware_download_popup",
                                                      "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.loc_snapshot("06_System_System_management_firmware_download_popup",
                                        "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        # check video
        self.tc_loc_driver.find_element_by_loc_text("Video").click()
        self.tc_loc_driver.loc_snapshot("10_Video_image_quality", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("10_Video_image_quality", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Camera").click()
        self.tc_loc_driver.find_element_by_loc_text("Transition style",
                                                    name="tc_settings_menu_video_transition").next_sibling().click()

        self.tc_loc_driver.loc_snapshot("11_Video_Camera", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("11_Video_Camera", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("Monitor").click()
        self.tc_loc_driver.find_element_by_loc_text("Region frequency").next_sibling().click()
        self.tc_loc_driver.loc_snapshot("12_Video_Monitor", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("12_Video_Monitor", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("Reset", name="tc_settings_menu_video_reset").click()
        self.tc_loc_driver.loc_snapshot("13_Video_Reset", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("13_Video_Reset", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text(text="Reset video settings",
                                                    name="tc_settings_menu_video_reset_settings").next_sibling().click()
        self.tc_loc_driver.loc_snapshot("13_Video_Reset_Popup", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        # check audio
        self.tc_loc_driver.click_point(150, 470)
        self.tc_loc_driver.loc_snapshot("14_Audio", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("14_Audio", "vb_zoom_jabra_meeting_setting")

        # check network
        self.tc_loc_driver.find_element_by_loc_text("Network", name="tc_settings_menu_connectivity_title").click()

        self.tc_loc_driver.find_element_by_loc_text("Network (IPv4)").click()
        self.tc_loc_driver.loc_snapshot('15_Network_Information_1', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("15_Network_Information_1", "vb_zoom_jabra_meeting_setting")

        self.tc_cmd_driver.exec_adb_shell_cmd(f"input swipe {self.x} {self.y2} {self.x} {self.y1}")
        self.tc_loc_driver.find_element_by_loc_text("LAN").click()
        self.tc_loc_driver.loc_snapshot('15_Network_Information_2', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("15_Network_Information_2", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("View or configure proxy settings.").next_sibling().click()
        self.tc_loc_driver.check_text_in_current_page("15_Network_Information_proxy_server",
                                                      "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.loc_snapshot('15_Network_Information_proxy_server', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Bluetooth", name="tc_settings_menu_network_bluetooth").click()
        self.tc_loc_driver.loc_snapshot("16_Network_Bluetooth", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("16_Network_Bluetooth", "vb_zoom_jabra_meeting_setting")

        # Check general
        self.tc_loc_driver.find_element_by_loc_text("General", name="tc_settings_menu_general_title").click()
        self.tc_loc_driver.find_element_by_loc_text("Date and time").wait_for_appearance()
        self.tc_loc_driver.find_element_by_loc_text("Date and time").click()
        self.tc_loc_driver.loc_snapshot('17_General_Region_data_time', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("17_Region_data_time", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("Change").click()
        self.tc_loc_driver.loc_snapshot('17_General_Change_Ntp_Popup', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("17_General_Change_Ntp_Popup", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Language").next_sibling().click()
        self.tc_loc_driver.loc_snapshot('17_General_Region_data_time_language_popup', "vb_zoom_jabra_meeting_setting",
                                        3)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Time zone").next_sibling().click()
        self.tc_loc_driver.loc_snapshot('17_General_Region_data_time_time_zone_popup', "vb_zoom_jabra_meeting_setting",
                                        3)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Support").click()
        self.tc_loc_driver.loc_snapshot('19_General_Support_info', "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("19_General_Support_info", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("System reset").click()
        self.tc_loc_driver.loc_snapshot("20_General_System_Reset", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("20_General_System_Reset", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("Reset").click()
        self.tc_loc_driver.loc_snapshot("20_General_User_Default_Setting_Reset", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("20_General_User_Default_Setting_Reset",
                                                      "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Factory reset").get(1).click()
        self.tc_loc_driver.loc_snapshot("20_General_Factory_Reset", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("20_General_Factory_Reset", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.find_element_by_loc_text("Restart", name="all_system_status_reboot_button").click()
        self.tc_loc_driver.loc_snapshot("20_General_Restart", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("20_General_Restart", "vb_zoom_jabra_meeting_setting")
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        # Check Account
        self.tc_loc_driver.nico(index="6", class_name="android.view.View").click()
        self.tc_loc_driver.loc_snapshot("21_Account_Access", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("21_Account_Acess", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("Change password").click()
        self.tc_loc_driver.loc_snapshot("21_Account_Change_Password_Popup", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Cancel").click()

        self.tc_loc_driver.nico(textContains="Jabra Support").click()
        self.tc_loc_driver.loc_snapshot("22_Account_Jabra_support", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.check_text_in_current_page("22_Account_Jabra_support", "vb_zoom_jabra_meeting_setting")

        self.tc_loc_driver.find_element_by_loc_text("View").click()
        self.tc_loc_driver.loc_snapshot("22_Account_Privacy_Policy", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Close").click()

        self.tc_loc_driver.find_element_by_loc_text("View").get(1).click()
        self.tc_loc_driver.loc_snapshot("22_Account_End_User_License_Agreement", "vb_zoom_jabra_meeting_setting", 2)
        self.tc_loc_driver.find_element_by_loc_text("Close").click()

        self.tc_cmd_driver.exec_adb_shell_cmd(
            "am start -S -n com.microsoft.skype.teams.ipphone/com.microsoft.skype.teams.Launcher")