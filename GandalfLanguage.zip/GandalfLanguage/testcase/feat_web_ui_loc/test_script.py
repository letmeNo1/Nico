import time

from DrissionPage import ChromiumPage
from DrissionPage.action_chains import ActionChains
from DrissionPage.errors import ElementNotFoundError

languages_dict = {"zh": 0, "cs": 1, "da": 2, "nl": 3, "en-US": 4, "fi": 5, "fr": 6, "de": 7, "hu": 8, "it": 9,
                  "nb": 10,
                  "pl": 11, "ru": 12, "es": 13, "sv": 14, "tr": 15, "ja": 16}


class WebTestScript:
    def __init__(self, loc_web_driver, account, password, endpoint):
        self.loc_web_driver = loc_web_driver
        self.account = account
        self.password = password
        self.endpoint = endpoint
        self.action = ActionChains(ChromiumPage())
        self.module = f"{self.endpoint}_Web_UI_JabraMeetingSetting"

    def installation_follow(self, language):
        self.loc_web_driver.find_element("@name=username", timeout=5).input(self.account)
        self.loc_web_driver.find_element("@name=password", timeout=5).input(self.password)
        self.loc_web_driver.find_element("@type=submit").click()
        self.loc_web_driver.scroll_to_see(
            f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language) + 1}]')
        self.loc_web_driver.find_element(
            f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language) + 1}]').click()
        self.loc_web_driver.find_element("@type=submit").click()
        self.loc_web_driver.loc_snapshot("00_1_privacy_policy", self.module)
        self.loc_web_driver.find_element('xpath://*[@id="root"]/div[2]/div/div/div[2]/button[2]', timeout=10).click()
        self.loc_web_driver.scroll_to_bottom('xpath://*[@id="root"]/div[2]/div/div/div[1]')
        self.loc_web_driver.loc_snapshot("00_2_license_agreement", self.module)
        time.sleep(5)
        self.loc_web_driver.find_element('xpath://*[@id="root"]/div[2]/div/div/div[2]/button[2]', timeout=10).click()
        try:
            self.loc_web_driver.find_element_by_loc_text("Clock", timeout=20).click()
        except ElementNotFoundError:
            self.loc_web_driver.find_element_by_loc_text("Network settings",timeout=20).click()
            self.loc_web_driver.find_element_by_loc_text("Save").click()
            self.loc_web_driver.find_element_by_loc_text("Clock", timeout=20).click()
        self.loc_web_driver.loc_snapshot("00_3_data_and_time", self.module)
        self.loc_web_driver.find_element("@type=submit").click()
        self.loc_web_driver.find_element("text:Microsoft Teams Rooms",timeout=30)

        self.loc_web_driver.loc_snapshot("00_4_select_vaas", self.module)
        self.loc_web_driver.find_element("text:Microsoft Teams Rooms").click()
        self.loc_web_driver.find_element("@type=submit").click()

    def login_page(self):
        self.loc_web_driver.find_element("@name=username", timeout=5).input(self.account)
        self.loc_web_driver.find_element("@name=password", timeout=5).input(self.password)
        self.loc_web_driver.loc_snapshot("01_login_login", self.module)
        self.loc_web_driver.check_text_in_current_page("01_login_login", self.module)
        self.loc_web_driver.find_element("@type=submit").click()
        time.sleep(1)

    def system_status_page(self):
        # Systemstatus page
        self.loc_web_driver.refresh_page()
        self.loc_web_driver.find_element_by_loc_text("Connected", timeout=20).click()
        self.loc_web_driver.loc_snapshot("02_System_status_Network", self.module)
        self.loc_web_driver.check_text_in_current_page("02_System_status_Network", self.module)
        self.loc_web_driver.find_element_by_loc_text("Firmware", timeout=5).click()
        self.loc_web_driver.loc_snapshot("03_System_status_Firmware", self.module)
        self.loc_web_driver.check_text_in_current_page("03_System_status_Firmware", self.module)

        self.loc_web_driver.find_element_by_loc_text("Language", timeout=5).click()
        self.loc_web_driver.loc_snapshot("04_System_status_Language", self.module)
        self.loc_web_driver.check_text_in_current_page("04_System_status_Language", self.module)

    def system_page(self):
        self.loc_web_driver.find_element("@href=#/system/management", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Room name", timeout=5).click()
        self.loc_web_driver.loc_snapshot("05_System_System_management", self.module)
        self.loc_web_driver.check_text_in_current_page("05_System_System_management", self.module)

        self.loc_web_driver.find_element_by_loc_text("Devices", timeout=5).click()
        time.sleep(1)
        self.loc_web_driver.loc_snapshot("06_System_About_system_1", self.module)
        self.loc_web_driver.check_text_in_current_page("06_System_About_system_1", self.module)
        location = self.loc_web_driver.find_element_by_loc_text("Firmware version", timeout=5).location
        print(location)
        self.action.move_to((location[0], location[1] + 1150))
        self.loc_web_driver.loc_snapshot("07_System_About_system_2", self.module)
        self.loc_web_driver.check_text_in_current_page("07_System_About_system_2", self.module)

    def video_page(self):
        time.sleep(1)
        self.loc_web_driver.find_element("@href=#/video/image-quality", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Brightness", timeout=5).click()
        self.loc_web_driver.loc_snapshot("08_Video_Image_Quality", self.module)
        self.loc_web_driver.check_text_in_current_page("08_Video_Image_Quality", self.module)
        self.loc_web_driver.find_element("@href=#/video/settings", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Transition style",
                                                     name="tc_settings_menu_video_transition").click()
        self.loc_web_driver.loc_snapshot("09_Video_Camera", self.module)
        self.loc_web_driver.check_text_in_current_page("09_Video_Camera", self.module)
        self.loc_web_driver.find_element(
            'xpath://*[@id="root"]/div/div[2]/form/div[3]/div/div[3]/div[2]/label/div/div/input').click()
        self.loc_web_driver.check_text_in_current_page("09_1Video_Camera_Transition_style", self.module)
        # self.loc_web_driver.find_element("@xmlns=http://www.w3.org/2000/svg").click()
        # self.loc_web_driver.loc_snapshot("09_1_Video_Camera_mode", self.module)
        # self.loc_web_driver.find_element("@name=modal-button").click()
        self.loc_web_driver.find_element("@name=display-adjustments", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Standby interval in seconds", timeout=5).click()
        self.loc_web_driver.loc_snapshot("10_Video_Monitor", self.module)
        self.loc_web_driver.check_text_in_current_page("10_Video_Monitor", self.module)
        self.loc_web_driver.find_element("@href=#/video/reset", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Reset to the default video settings.",
                                                     name="tc_settings_menu_video_reset_settings_message",
                                                     timeout=5).click()
        time.sleep(2)
        # self.loc_web_driver.find_element_by_loc_text(self.page,"text=Reset to the default video settings.", timeout=5).click()
        self.loc_web_driver.loc_snapshot("11_Video_Rest", self.module)
        self.loc_web_driver.check_text_in_current_page("11_Video_Rest", self.module)
        self.loc_web_driver.find_element("@name=v_r_reset", timeout=5).click()
        time.sleep(3)
        self.loc_web_driver.loc_snapshot("12_Video_Rest_Popup", self.module)
        self.loc_web_driver.check_text_in_current_page("12_Video_Rest_Popup", self.module)
        self.loc_web_driver.find_element("@name=modal-button", timeout=5).click()

    def audio_page(self):
        self.loc_web_driver.find_element("@href=#/audio/audio", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Microphone volume", timeout=5).click()
        self.loc_web_driver.loc_snapshot("13_Audio", self.module)
        self.loc_web_driver.check_text_in_current_page("13_Audio", self.module)

    def network_page(self):
        # network/information
        self.loc_web_driver.find_element("@href=#/network/information", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Connection status", timeout=5).click()
        self.loc_web_driver.loc_snapshot("14_Network_Information_1", self.module)
        self.loc_web_driver.check_text_in_current_page("14_Network_Information_1", self.module)
        location = self.loc_web_driver.find_element_by_loc_text("Connection status", timeout=5).location
        self.action.move_to((location[0], location[1] + 1100))
        time.sleep(1)
        self.loc_web_driver.loc_snapshot("15_Network_Information_2", self.module)
        self.loc_web_driver.check_text_in_current_page("15_Network_Information_2", self.module)
        location = self.loc_web_driver.find_element_by_loc_text("Proxy server", timeout=5).location
        self.action.move_to((location[0], location[1] + 100))
        time.sleep(1)
        self.loc_web_driver.loc_snapshot("16_Network_Information_3", self.module)
        self.loc_web_driver.check_text_in_current_page("16_Network_Information_3", self.module)
        location = self.loc_web_driver.find_element_by_loc_text("Bypass proxy for", timeout=5).location
        self.action.move_to((location[0], location[1] + 100))
        time.sleep(1)
        self.loc_web_driver.loc_snapshot("17_Network_Information_4", self.module)
        self.loc_web_driver.check_text_in_current_page("17_Network_Information_4", self.module)
        self.loc_web_driver.find_element_by_loc_text("Bluetooth", timeout=5).click()

    def general_page(self):
        # General
        self.loc_web_driver.find_element("@href=#/general/region", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Language", timeout=5).click()
        self.loc_web_driver.loc_snapshot("18_General_Region_and_language_1", self.module)
        self.loc_web_driver.check_text_in_current_page("18_General_Region_and_language_1", self.module)
        location = self.loc_web_driver.find_element_by_loc_text("Time Server (NTP)", timeout=5).location
        self.action.move_to((location[0], location[1] + 100))

        self.loc_web_driver.loc_snapshot("19_General_Region_and_language_2", self.module)
        self.loc_web_driver.check_text_in_current_page("19_General_Region_and_language_2", self.module)
        self.loc_web_driver.find_element_by_loc_text("Support", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Description", timeout=5).click()

        self.loc_web_driver.loc_snapshot("20_General_Support", self.module)
        self.loc_web_driver.check_text_in_current_page("20_General_Support", self.module)
        self.loc_web_driver.find_element_by_loc_text("System reset", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Custom configuration reset", timeout=5).click()

        self.loc_web_driver.loc_snapshot("21_General_System_reset", self.module)
        self.loc_web_driver.check_text_in_current_page("21_General_System_reset", self.module)

        time.sleep(2)
        self.loc_web_driver.find_element_by_name_and_click("g_sr_custom_configuration_reset")
        time.sleep(0.5)
        self.loc_web_driver.loc_snapshot("21_1_General_Custom_Configuration_Reset", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")
        time.sleep(2)

        self.loc_web_driver.find_element_by_name_and_click("g_sr_reset")
        self.loc_web_driver.loc_snapshot("21_2_General_System_Reset", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")

        time.sleep(2)
        self.loc_web_driver.find_element_by_name_and_click("g_sr_system_restart")
        self.loc_web_driver.loc_snapshot("21_3_General_System_Restart", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")

    def account_page(self):
        # Account
        self.loc_web_driver.find_element("@href=#/account/account", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Web Console", timeout=5).click()
        self.loc_web_driver.loc_snapshot("22_Account", self.module)
        self.loc_web_driver.check_text_in_current_page("22_Account", self.module)

        self.loc_web_driver.find_element_by_loc_text("Change password", timeout=5).click()
        self.loc_web_driver.find_element("@name=confirmPassword").click()
        self.loc_web_driver.find_element("@name=a_a_password").click()
        self.loc_web_driver.find_element("@name=confirmPassword").click()
        self.loc_web_driver.loc_snapshot("22_1_Account_Change_Password", self.module)
        time.sleep(2)
        self.loc_web_driver.refresh_page()

        self.loc_web_driver.find_element_by_loc_text("Jabra Support", timeout=5).click()
        self.loc_web_driver.find_element_by_loc_text("Support content", timeout=5).click()
        self.loc_web_driver.loc_snapshot("23_Account_Jabra_Support", self.module)
        self.loc_web_driver.check_text_in_current_page("23_Account_Jabra_Support", self.module)

        self.loc_web_driver.find_element_by_loc_text("View Privacy Policy").click()
        time.sleep(2)
        self.loc_web_driver.loc_snapshot("23_1_Account_View_Privacy_Policy", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")

        time.sleep(2)
        self.loc_web_driver.find_element_by_name_and_click("a_js_end_user_license_agreement")
        time.sleep(2)
        self.loc_web_driver.loc_snapshot("23_2_Account_License_Agreement", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")

        self.loc_web_driver.find_element_by_loc_text("Download logs").click()
        time.sleep(2)
        self.loc_web_driver.loc_snapshot("23_3_Account_Download_Logs", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")

    def logout(self):
        # Account
        self.loc_web_driver.find_element_by_loc_text("Logout", timeout=5).click()
        time.sleep(2)

        self.loc_web_driver.loc_snapshot("24_Logout", self.module)
        self.loc_web_driver.find_element_by_name_and_click("modal-button")
        self.loc_web_driver.refresh_page()
