import os

from DrissionPage import ChromiumPage


from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import get_web_ui_url, change_language
from SpecialTestSubject.GandalfLanguage.base.driver.loc_web_driver import LocWebDriver
from SpecialTestSubject.GandalfLanguage.base.recording import PCRecording
from SpecialTestSubject.GandalfLanguage.testcase.base import Base
from SpecialTestSubject.GandalfLanguage.testcase.feat_web_ui_loc.test_script import WebTestScript


class TestTCWebUIFlow(Base):
    def setup(self):
        self.account = "admin"
        self.password = Base().tc_udid[-6:]
        lang = os.getenv("Current_Language")
        change_language(lang, Base().tc_udid, isWeb=True)
        self.page = ChromiumPage()
        current_time = os.getenv('Current_Time')
        language = os.getenv("Current_Language")
        self.path = os.getcwd() + f"\\WebScreenShot\\{current_time}\\{language}\\"
        self.tc_PCRecording = PCRecording("test_tc_web_ui_flow")
        self.tc_PCRecording.start()

    def teardown(self):
        self.tc_PCRecording.stop()

    def test_tc_web_ui_flow(self, language):
        print(language)
        url = get_web_ui_url(Base().tc_udid)
        self.page.clear_cache()
        self.page.get(f"http://{url}")
        loc_web_driver = LocWebDriver(self.page)
        web_test_script = WebTestScript(loc_web_driver,self.account,self.password,"TC")
        web_test_script.login_page()
        web_test_script.system_status_page()
        web_test_script.system_page()
        web_test_script.video_page()
        web_test_script.audio_page()
        web_test_script.network_page()
        web_test_script.general_page()
        web_test_script.account_page()
        web_test_script.logout()


