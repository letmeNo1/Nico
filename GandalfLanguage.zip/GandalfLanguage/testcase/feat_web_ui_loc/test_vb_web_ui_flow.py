import os
import time

from DrissionPage import ChromiumPage
from DrissionPage.action_chains import ActionChains
from DrissionPage.mixpage.mix_page import MixPage

from SpecialTestSubject.GandalfLanguage.base.driver.change_gandalf_language import get_web_ui_url, change_language
from SpecialTestSubject.GandalfLanguage.base.driver.loc_web_driver import LocWebDriver, converting_strings
from SpecialTestSubject.GandalfLanguage.base.recording import PCRecording
from SpecialTestSubject.GandalfLanguage.testcase.base import Base
from SpecialTestSubject.GandalfLanguage.testcase.feat_web_ui_loc.test_script import WebTestScript


class TestTCWebUIFlow(Base):
    def setup(self):
        self.account = "admin"
        self.password = Base().vb8250_udid[-6:]
        self.lang = os.getenv("Current_Language")
        current_time = os.getenv('Current_Time')
        self.path = os.getcwd() + f"\\WebScreenShot\\{current_time}\\{self.lang}\\"
        self.vb_PCRecording = PCRecording("test_vb_web_ui_flow")
        self.vb_PCRecording.start()

    def teardown(self):
        self.vb_PCRecording.stop()

    def test_vb_web_ui_flow(self, language):
        self.page = ChromiumPage()
        url = get_web_ui_url(Base().vb8250_udid)
        self.page.clear_cache()
        self.page.get(f"http://{url}")
        loc_web_driver = LocWebDriver(self.page)
        web_test_script = WebTestScript(loc_web_driver, self.account, self.password, "VB")
        web_test_script.installation_follow(self.lang)
        web_test_script.system_status_page()
        web_test_script.system_page()
        web_test_script.video_page()
        web_test_script.audio_page()
        web_test_script.network_page()
        web_test_script.general_page()
        web_test_script.account_page()
        web_test_script.logout()

