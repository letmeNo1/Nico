import json
import os
import time
from distutils.util import strtobool

import pytest
from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger

from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.driver.gnp_private_driver import GnpPrivateDriver
from SpecialTestSubject.GandalfLanguage.base.driver.pcos_driver.pcos_driver import PcosDriver
from SpecialTestSubject.GandalfLanguage.testcase.base import Base


@pytest.fixture(scope="function", autouse=True)
def a_vb_factory_reset(request):
    currently_running_function = request.node.name.split("[")[0]
    if "vb" in currently_running_function:
        gnp_ins = GnpPrivateDriver()
        if strtobool(request.config.getoption("--fr")):
            assert gnp_ins.gnp_write(Base().vb8250_pid, Base().vb8250_udid, "01", "13", "11", ["00"])
        time.sleep(3)

@pytest.fixture(scope="function", autouse=True)
def a_tc_factory_reset(request):
    currently_running_function = request.node.name.split("[")[0]
    if "tc" in currently_running_function:
        gnp_ins = GnpPrivateDriver()
        if strtobool(request.config.getoption("--fr")):
            assert gnp_ins.gnp_write(Base().tc_pid, Base().tc_udid, "01", "13", "11", ["00"])
        time.sleep(3)

@pytest.fixture(scope="function", autouse=True)
def b_wait_vb_ready(request):
    currently_running_function = request.node.name.split("[")[0]
    if "vb" in currently_running_function:
        pcos_ins = PcosDriver()
        cmd_driver = CmdDriver(Base().vb8250_udid)
        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[function] wait_vb_ready")
            pcos_ins.wait_android_device_connected(Base().vb8250_pid, Base().vb8250_vid, 90)
            cmd_driver.exec_adb_cmd_wait_output(r"logcat -d -b events| grep boot_progress_enable_screen", 200)
            Logger.ins().file_logger().info("--->[function] vb already")
            clear_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -s ''"]
            time.sleep(5)
            cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
@pytest.fixture(scope="function", autouse=True)
def b_wait_tc_ready(request):
    currently_running_function = request.node.name.split("[")[0]
    if "tc" in currently_running_function:
        pcos_ins = PcosDriver()
        cmd_driver = CmdDriver(Base().tc_udid)
        if strtobool(request.config.getoption("--fr")):
            Logger.ins().file_logger().info("--->[function] wait_tc_ready")
            pcos_ins.wait_android_device_connected(Base().tc_pid, Base().tc_vid, 90)
            cmd_driver.exec_adb_cmd_wait_output(r"logcat -d -b events| grep boot_progress_enable_screen", 200)
            Logger.ins().file_logger().info("--->[function] vb already")
            clear_pre_pair_cmds = ["cd system/vendor/bin", "./jose_service_controller device -s ''"]
            time.sleep(5)
            cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
@pytest.fixture(scope="function", autouse=True)
def c_set_ntp_server():
    cmd_driver = CmdDriver(Base().vb8250_udid)
    cmd_driver.exec_adb_shell_cmd("settings put global ntp_server ntp1.aliyun.com")
    cmd_driver = CmdDriver(Base().tc_udid)
    cmd_driver.exec_adb_shell_cmd("settings put global ntp_server ntp1.aliyun.com")

def pytest_generate_tests(metafunc):
    if "language" in metafunc.fixturenames:
        env_conf_path = r"%s\languages.json" % (os.path.dirname(__file__))
        print(env_conf_path)
        with open(env_conf_path) as f:
            data = json.load(f)
        metafunc.parametrize("language", data.get("languages"))


def pytest_runtest_protocol(item):
    language = item.callspec.params.get("language")
    if language:
        os.environ["Current_Language"] = language
        os.environ["Current_Languages_File_Path"] = r"C:\plt--vendor--jabra--packages--apps--jabra-meeting-android\app\src\main\res"
    return None


@pytest.fixture(scope="function", autouse=True)
def esc_chrome():
    yield
    cmd_driver = CmdDriver()
    cmd_driver.exec_pcos_cmd("taskkill /IM chrome.exe")
