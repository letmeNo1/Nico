# Define constant value
# Define data from Json file


import json, os

GNP_ACK_CMD = "FF"
GNP_NACK_CMD = "FE"

Gandalf_TC = "Gandalf_TC"
Gandalf_VB8250 = "Gandalf_VB8250"
Gandalf_VB404 = "Gandalf_VB404"

PC_AG_Win = "PC_AG_Win"


class Base:
    @property
    def gn_vid(self):
        return "0B0E"

    @property
    def get_sys_info(self):
        return json.loads(os.getenv("SysInfo"))

    @property
    def gandalf_tc(self):
        return self.get_sys_info.get("Gandalf_TC")

    @property
    def gandalf_vb8250(self):
        return self.get_sys_info.get("Gandalf_VB8250")

    @property
    def gandalf_vb404(self):
        return self.get_sys_info.get("Gandalf_VB404")

    @property
    def gandalf_tc_teams(self):
        return self.gandalf_tc.get("Teams")

    @property
    def gandalf_tc_zoom(self):
        return self.gandalf_tc.get("Zoom")

    @property
    def gandalf_vb_teams(self):
        return self.gandalf_vb8250.get("Teams")

    @property
    def gandalf_vb_zoom(self):
        return self.gandalf_vb8250.get("Zoom")

    @property
    def tc_udid(self):
        return self.gandalf_tc.get("udid")

    @property
    def tc_pid(self):
        return self.gandalf_tc.get("pid")

    @property
    def tc_vid(self):
        return self.gandalf_tc.get("vid")

    @property
    def tc_android_model(self):
        return self.gandalf_tc.get("android_model")

    @property
    def vb8250_udid(self):
        return self.gandalf_vb8250.get("udid")

    @property
    def vb8250_pid(self):
        return self.gandalf_vb8250.get("pid")

    @property
    def vb8250_vid(self):
        return self.gandalf_vb8250.get("vid")

    @property
    def vb8250_android_model(self):
        return self.gandalf_vb8250.get("android_model")

    @property
    def vb404_udid(self):
        return self.gandalf_vb404.get("udid")

    @property
    def vb404_pid(self):
        return self.gandalf_vb404.get("pid")

    @property
    def vb404_vid(self):
        return self.gandalf_vb404.get("vid")
