import datetime
import json
import os

import pytest
import warnings


def pytest_addoption(parser):
    parser.addoption(
        "--fr", action="store", default="True",
        help="Only Used for Feat Installation Flow Debug",
    )
@pytest.fixture(scope="function", autouse=True)
def set_test_log(request):
    currently_running_function = request.node.name.split("[")[0]
    os.environ["currently_running_function"] = currently_running_function

@pytest.fixture(scope="session", autouse=True)
def set_env():
    current_time = datetime.datetime.now()
    os.environ['Current_Time'] = formatted_time = current_time.strftime("%Y_%m_%d_%H_%M_%S")
    env_conf_path = r"%s\conf\system.json" % (os.path.dirname(__file__))
    with open(env_conf_path, encoding='utf-8') as env_conf_file:
        env_conf = env_conf_file.read()
    os.environ["SysInfo"] = env_conf
