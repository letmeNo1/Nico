# Author: Felix He (GN Audio)
# Contact: fhe@jabra.com    

import traceback, os, re, time

from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger


class GnpPrivateDriver(object):

    def __init__(self):
        current_dir = os.getcwd()
        dir_name = "GandalfLanguage"
        index = current_dir.rfind(dir_name)
        if index != -1:
            path = current_dir[:index + len(dir_name)] + "\\"
        self.rungnp = path +"base\\tools\\exe\\GnpPrivate.exe"
        print(self.rungnp)
        self.cmd_driver = CmdDriver()

    def __assert_result(self, rst, message="assert_result False"):
        if not rst:
            raise Exception(message)

    def send_gnp(self, pid, esn, cmd):
        cmd = self.rungnp + " -p " + pid + " -esn " + esn + " -c " + '"%s"' % cmd.strip()
        # with self.cmd_driver.exec_poos_cmd(cmd) as re_data:
        re_data = self.cmd_driver.exec_pcos_cmd(cmd).decode('utf-8')
        time.sleep(2)
        ack = re_data.replace('\n', '')
        Logger.ins().file_logger().info("send_gnp:\n cmd:'%s'\n ack:'%s'" % (cmd, ack))
        return ack.split(' ')

    def gnp_write(self, pid, esn, dest, main_cmd, sub_cmd, param_list):
        ret_msg = None
        try:
            params = " ".join(param_list)
            att_len = 0x80 | (6 + len(param_list))
            att_len = str(hex(att_len)).replace('0x', '')
            cmd = "%s %s %s %s %s %s %s" % (dest, "00", "AA", att_len, main_cmd, sub_cmd, params)
            ack_list = self.send_gnp(pid, esn, cmd)

            self.__assert_result(len(ack_list) >= 5, "Data Length Error")
            ret_msg = ack_list[4]

        except Exception as ex:
            ret_msg = None
            Logger.ins().file_logger().error(traceback.format_exc())

        return ret_msg

    '''
    Params: ret_str, True when GNP return string, like FW version, False when GNP return hex directly
    '''

    def gnp_read(self, pid, esn, dest, main_cmd, sub_cmd, param_list, ret_str=False):
        ret_msg = ''
        try:
            Logger.ins().file_logger().info("gnp_read: main_cmd:%s, sub_cmd:%s" % (main_cmd, sub_cmd))

            params = " ".join(param_list)
            att_len = 0x40 | (6 + len(param_list))
            att_len = str(hex(att_len)).replace('0x', '')
            cmd = "%s %s %s %s %s %s %s" % (dest, "00", "AA", att_len, main_cmd, sub_cmd, params)
            ack_list = self.send_gnp(pid, esn, cmd)

            # check gnp header
            self.__assert_result(len(ack_list) >= 6, "Header Length ERROR")
            self.__assert_result(ack_list[0] == "00", "Source Address ERROR")
            self.__assert_result(ack_list[1] == dest, "DEST Address ERROR")
            self.__assert_result(ack_list[2] == "AA", "Package ID ERROR")
            self.__assert_result(ack_list[4] == main_cmd, "Main CMD ERROR")
            self.__assert_result(ack_list[5] == sub_cmd, "Sub CMD ERROR")

            # check gnp package length
            ack_len = int(ack_list[3], 16) & 0x3f
            self.__assert_result(ack_len == len(ack_list), "Package Length ERROR")

            # if GNP read return string
            if ret_str:
                # no word for data length, main cmd is GNP_CONFIG_CMD("13"), subcmd is GNP_CONFIG_BLUETOOTH_NAME("56")
                if (main_cmd in ["13"]) and (sub_cmd in ["56"]):
                    for i in range(ack_len - 6):
                        ret_msg += chr(int(ack_list[6 + i], 16))
                # first word is data length
                else:
                    data_len = int(ack_list[6], 16)
                    self.__assert_result((data_len == ack_len - 7), "Data Length ERROR")
                    for i in range(data_len):
                        ret_msg += chr(int(ack_list[7 + i], 16))
            else:
                ret_msg = " ".join(ack_list[6:])

        except Exception as ex:
            ret_msg = None
            Logger.ins().file_logger().error(traceback.format_exc())

        return ret_msg

    '''
    ack_valid = True means will return msg,False will not return GNP msg
    '''

    def gnp_event(self, pid, esn, dest, main_cmd, sub_cmd, param_list, ack_valid=True):
        ret_msg = None
        try:
            params = " ".join(param_list)
            att_len = 0x00 | (6 + len(param_list))
            # att_len = str(hex(att_len)).replace('0x','')
            att_len = '{:02x}'.format(att_len)
            cmd = "%s %s %s %s %s %s %s" % (dest, "00", "AA", att_len, main_cmd, sub_cmd, params)
            ack_list = self.send_gnp(pid, esn, cmd)
            if ack_valid == True:
                self.__assert_result(len(ack_list) >= 5, "Data Length Error")
                ret_msg = ack_list[4]
        except Exception as ex:
            ret_msg = None
            Logger.ins().file_logger().error(traceback.format_exc())

        return ret_msg

    def check_device_ready(self, pid):
        rst = True
        try:
            devices_pids = self.__get_devices_info()
            rst = pid in devices_pids.values()
            Logger.ins().file_logger().info(
                "--->[check_device_ready: %s] pid=%s, in %s" % (rst, pid, devices_pids.values()))

        except Exception as ex:
            rst = False
            Logger.ins().file_logger().error(traceback.format_exc())
        return rst

    def __get_devices_info(self):
        device_info = {}
        # return dict {'Jabra Link 370': '0x245d', 'Jabra QCC5120 test': '0x249c'}
        try:
            send = self.cmd_driver.exec_poos_cmd(self.rungnp + " device")
            list = send.read()
            duts = re.findall('Jabra.*?(?=pid)', list)
            pids = re.findall('0x.*?(?=\\n)', list)
            duts = self.__list_remove_space(duts)
            pids = self.__list_remove_space(pids)
            device_info = dict(zip(duts, pids))
        except Exception as ex:
            Logger.ins().file_logger().error("--->[get_devices_info] fail: %s" % traceback.format_exc())
        return device_info

    def __list_remove_space(self, list):
        try:
            i = 0
            for dut in list:
                list[i] = dut.strip()
                i += 1
        except Exception as ex:
            Logger.ins().file_logger().error("--->[__list_remove_space] fail: %s" % traceback.format_exc())
        return list
