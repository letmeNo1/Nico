import os
import time

from SpecialTestSubject.GandalfLanguage.base.nico_base import NicoBase

from SpecialTestSubject.GandalfLanguage.base.driver.converting_strings import converting_strings
import lxml.etree as ET


class TranslationFileError(Exception):
    pass


class LocDriver(NicoBase):
    def __init__(self, udid):

        super().__init__(udid)

    '''
    This method is only used for localization testing
    '''

    def loc_snapshot(self, step, module, delay=0):
        time.sleep(delay)
        current_time = os.getenv('Current_Time')
        language = os.getenv("Current_Language")
        currently_running_function = os.getenv("currently_running_function")
        path = os.getcwd() + f"\\ScreenShot\\{currently_running_function}_{current_time}\\{language}\\"
        if not os.path.exists(path):
            os.system(f"mkdir {path}")
        os.system(f'''del {path}\\{language}_{module}_{step}.png''')
        self.take_snapshot(f"{language}_{module}_{step}", path)


    '''
    This method is only used for localization testing
    '''

    def click_point(self, x, y):
        command = f'adb -s {self.udid} shell input tap {x} {y}'
        os.system(command)

    '''
    This method is only used for localization testing
    '''

    def converting_strings(self,text,name=None):
        convert_text = ""
        if os.getenv("Current_Language") != "en-US":
            convert_text = converting_strings(text, name)
        return convert_text

    def find_element_by_loc_text(self, text, name=None, timeout=5):
        convert_text = text
        if os.getenv("Current_Language") != "en-US":
            convert_text = converting_strings(text, name)
        self.nico(text=convert_text).wait_for_appearance(timeout)
        return self.nico(text=convert_text)

    '''
        This method is only used for localization testing
        '''

    def check_loc_text(self, text, name=None, timeout=5):
        convert_text = text
        if os.getenv("Current_Language") != "en-US":
            convert_text = converting_strings(text, name)
        self.nico(text=convert_text).wait_for_appearance(timeout)

    def __check_text(self, root, target_value):
        stack = [root]

        while stack:
            element = stack.pop()
            print(element.text)

            # 判断当前元素的text是否包含目标值
            if element.text and target_value in element.text:
                return True

            # 将子元素入栈，继续遍历
            stack.extend(element)
        return False

    def __check_text_in_file(self, file_path, text_to_find):
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if text_to_find in line:
                    return True
        return False

    def check_text_in_current_page(self, step, module):
        language = os.getenv("Current_Language")
        if language =="zh":
            language ="zh-rCN"
        current_time = os.getenv('Current_Time')
        currently_running_function = os.getenv("currently_running_function")
        path = os.getcwd() + f"\\ScreenShot\\{currently_running_function}_{current_time}\\"
        error_file_path = path + "error.txt"
        if not os.path.exists(path):
            os.system(f"mkdir {path}")
        if not os.path.exists(error_file_path):
            # 文件不存在，使用 open 函数创建新文件
            with open(path + "error.txt", "w", encoding="utf-8"):
                pass
        if language != "en-US":
            language_xml_folder = os.getenv("Current_Languages_File_Path")
            other_lang_xml_file_path = language_xml_folder + rf"\values-{language}\strings.xml"
            tree = ET.parse(other_lang_xml_file_path)
            other_lang_root = tree.getroot()
            root = self.nico().get_root_node()
            for child in root.iter():
                if child.get("package") != "com.android.systemui":
                    if child.get("text") is not None:
                        if not self.__check_text(other_lang_root, child.get("text")):
                            if not self.__check_text_in_file(error_file_path, f"text = {child.get('text')}"):
                                string_to_write = f"{language}_{module}_{step}.png :text = {child.get('text')} isn't translate"
                                with open(error_file_path, 'a',
                                          encoding='utf-8') as file:  # 将 "your_file.txt" 替换为您要写入的文本文件的名称
                                    file.write(string_to_write + "\n")
                    elif child.get("content-desc") is not None:
                        if not self.__check_text(other_lang_root, child.get("content-desc")):
                            if not self.__check_text_in_file(error_file_path, f"text = {child.get('content-desc')}"):
                                string_to_write = f"{language}_{module}_{step}.png :text = {child.get('content-desc')} isn't translate"
                                with open(error_file_path, 'a',
                                          encoding='utf-8') as file:  # 将 "your_file.txt" 替换为您要写入的文本文件的名称
                                    file.write(string_to_write + "\n")
        #     other_lang_root = tree.getroot()
        #     root = self.nico.get_root_node()
        #     for child in root.iter():
        #         print(child.attrib["text"])
        # p_list = self.browser.s_eles('tag:p')
        # span_list = self.browser.s_eles('tag:span')
        # h1_list = self.browser.s_eles('tag:h1')
        # h3_list = self.browser.s_eles('tag:h3')
        # li_list = self.browser.s_eles('tag:li')
        # button_list = self.browser.s_eles('tag:button')
        # div_list = self.browser.s_eles('tag:div')
        # all_eles = p_list + span_list + h1_list + h3_list + li_list + button_list + div_list
        # for ele in all_eles:
        #     if ele.text != "" and ele.tag != "" and len(ele.children()) == 0:

        #             if not self.__check_text_in_file(error_file_path,f"tag = {ele.tag} text = {ele.text}"):
        #                 with open(error_file_path, 'a',encoding='utf-8') as file:  # 将 "your_file.txt" 替换为您要写入的文本文件的名称
        #                     file.write(string_to_write+"\n")