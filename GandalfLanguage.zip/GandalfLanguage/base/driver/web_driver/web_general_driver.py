import os
import sys
import time
import traceback
from DrissionPage import *
from selenium.webdriver import Keys

from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger


class WebGeneralDriver(object):

    def __init__(self):
        pass

    def open_web_ui(self,url):
        page = MixPage("d")
        page.clean_cache()
        page.set_window_size()
        page.get(url)

    def login_teams(self,url, account, login_code):
        data = None
        page = MixPage("d")
        page.clean_cache()
        page.set_window_size()
        page.get(url)
        page.ele("@name=otc", timeout=60).input(login_code)
        page.ele("@value=Next", timeout=60).click()
        page.ele("@name=loginfmt", timeout=60).input(account)
        page.ele("@value=Next", timeout=60).click()
        page.ele("@name=passwd", timeout=60).input("R&Dlab##")
        page.ele("@value=Sign in", timeout=60).click()
        time.sleep(3)
        page.ele("@id=idSIButton9", timeout=60).click()
        time.sleep(3)
        Logger.ins().std_logger().info("---> [PY][TeamsLogin]You have signed in to the Mic")
    """
    def get_driver(self):
        return webdriver.Chrome(service=Service(ChromeDriverManager().install()))

    def wait_element_visible(self, by, condition):
        return EC.visibility_of_element_located((by, condition))

    def wait_element_presence(self, by, condition):
        return EC.presence_of_element_located((by, condition))

    def get_display_name_cell_by_index(self, _index):
        return wait_element_visible(By.ID, "span[data-cell-row='{}']".format(_index))

    def scroll_up_into_view(self, driver, element):
        driver.execute_script("arguments[0].scrollIntoView(false);", element)

    def scroll_to_bottom(self, driver):
        js = "window.scrollTo(0, document.body.scrollHeight)"
        driver.execute_script(js)
        

    def login_tac(self, driver, tac_url, tac_username, tac_password):
        rst = True
        try:
            driver.get(tac_url) # open url
            login_input_field = self.wait_element_visible(By.NAME, 'loginfmt')
            next_button = self.wait_element_visible(By.CSS_SELECTOR, "input[data-report-event='Signin_Submit']")
            password_input_filed = self.wait_element_visible(By.NAME, 'passwd')
            overview_content = self.wait_element_visible(By.ID, "ap-AppMainContent")

            # login
            WebDriverWait(driver, 20).until(login_input_field).send_keys(tac_username)
            WebDriverWait(driver, 10).until(next_button).click()
            WebDriverWait(driver, 20).until(password_input_filed).send_keys(tac_password)
            WebDriverWait(driver, 10).until(next_button).click()
            WebDriverWait(driver, 10).until(next_button).click()

            # wait page loading
            WebDriverWait(driver, 60).until(overview_content)
        except:
            rst = False
            Logger.ins().file_logger().error(traceback.format_exc())
        return rst


    def open_page_device_info(self, driver, device_display_id, devices_count):
        rst = True
        try:
            # open device detail page
            driver.maximize_window()  
            for _index in range(int(devices_count)):
                device = WebDriverWait(driver, 20).until(
                    self.wait_element_presence(By.CSS_SELECTOR, "span[data-cell-row='{}'][data-cell-column='2']".format(_index)))
                if device.get_attribute("innerText") == device_display_id:
                    self.scroll_up_into_view(driver, device)
                    device = WebDriverWait(driver, 20).until(
                    self.wait_element_presence(By.CSS_SELECTOR, "span[data-cell-row='{}'][data-cell-column='0']".format(_index)))
                    device.click()
                    break
        except:
            rst = False
            Logger.ins().file_logger().error(traceback.format_exc())
        return rst


    def get_health_data_from_page_device_info(self, driver):
        software_health_data_dict = dict()
        try:
            health_tab = self.wait_element_visible(By.NAME, "Health")
            software_health = self.wait_element_visible(By.CSS_SELECTOR, "div[aria-label='Software health']")
            current_version_column = self.wait_element_visible(By.CSS_SELECTOR, "div[data-column='Current version']")
            software_typet_column = self.wait_element_visible(By.CSS_SELECTOR, "div[data-column='Software type']")
            # get software type and current_version from device detail
            health_tab_element = WebDriverWait(driver, 10).until(health_tab)
            self.scroll_up_into_view(driver, health_tab_element)
            health_tab_element.click()
            WebDriverWait(driver, 10).until(software_typet_column)
            software_type_list = driver.find_elements(By.CSS_SELECTOR, "div[data-column='Software type']")

            WebDriverWait(driver, 10).until(current_version_column)
            current_version_list = driver.find_elements(By.CSS_SELECTOR, "div[data-column='Current version']")
            for i, software_type in enumerate(software_type_list):
                software_type_value = software_type_list[i].text
                current_version_value = current_version_list[i].text
                software_health_data_dict[software_type_value] = current_version_value
            #Logger.ins().file_logger().info("---> [TacCommon][get_health_data_from_page_device_info] data=%s"% software_health_data_dict)
        except:
            software_health_data_dict = None
            Logger.ins().file_logger().error(traceback.format_exc())
        return software_health_data_dict  
    """
