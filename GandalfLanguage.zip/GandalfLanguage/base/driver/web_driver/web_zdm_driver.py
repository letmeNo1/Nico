import os
import sys
import datetime
import traceback
from base.systemlogger import Logger
from base.decorate import Decorate
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from base.systemlogger import Logger
from base.PlatformManagerWindows import assert_result


class WebZdmDriver(object):

    def __init__(self):
        pass
