import os
import sys
import time
import traceback
from DrissionPage import *
from base.arch.driver.tac_driver_v1_win10.get_device_health_data import GetDeviceHealthData
from selenium.webdriver import Keys

from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger


class TacGetDeviceHealthData:
    def __init__(self, tac_url="https://admin.teams.microsoft.com/dashboard", tac_username="benjaminye@jabralab.onmicrosoft.com", tac_password="Dug81564!", device_name="jabra-panacast1000 f72d38b8"):
        self.tac_url = tac_url
        self.tac_username = tac_username
        self.tac_password = tac_password
        self.device_name = device_name

        #self.tac_url = "https://admin.teams.microsoft.com/dashboard"
        #self.tac_username = "benjaminye@jabralab.onmicrosoft.com"
        #self.tac_password = "Dug81564!"
        #self.device_name = "jabra-panacast1000 f72d38b8"
        #self.device_name = "jabra-panacasttc 2917a9aac2a29a1e"

    def run(self):
        data = None
        try:
            page = MixPage("d")  
            
            page.clean_cache()
            page.set_window_size()
            page.get(self.tac_url)
            page.ele('@name=loginfmt', timeout=60).input(self.tac_username)
            page.ele("@value=Next", timeout=60).click()
            page.ele('@name=passwd', timeout=60).input(self.tac_password)
            page.ele("@value=Sign in", timeout=60).click()
            page.ele("css=input[data-report-event='Signin_Submit']").click(by_js=False)
            if page.ele('@name=Show all', timeout=1) == None:
                page.ele("@data-icon-name=GlobalNavButton", timeout=60).click()
                page.ele('@name=Show all').click()
            else:
                page.ele('@name=Show all').click()
            page.ele('Teams devices').click()
            page.ele('Teams Rooms on Android').click()
            page.scroll_to_see("@id=commandBarIconSearch")
            page.wait_ele("@text:mtr", timeout=60)
            page.ele("@id=commandBarIconSearch").click()
            page.ele("@id=advance-search").input(self.device_name)
            time.sleep(3)
            page.ele("@id=advance-search").input(Keys.ENTER)
            page.wait_ele(self.device_name, timeout=30)
            time.sleep(1)
            display_name = page.ele(self.device_name).parent(2).prev(2).text
            page.ele(display_name).click()
            page.ele("@name=Health", timeout=30).click()
            page.ele("Firmware", timeout=60)
            time.sleep(5)
            data = {}
            software_type_list = page.eles("@data-column=Software type")
            current_version_list = page.eles("@data-column=Current version")
            for i, software_type in enumerate(software_type_list):
                software_type_value = software_type_list[i].text
                current_version_value = current_version_list[i].text
                data[software_type_value] = current_version_value
            Logger.ins().std_logger().info("---> [PY][GetDeviceHealthData]:device={}, data={}".format(self.device_name, data))
            
        except:
            data = None
            Logger.ins().file_logger().error(traceback.format_exc())
        #page.close_driver()
        os.popen("TASKKILL /F /IM chrome.exe")
        return data


if __name__ == "__main__":
    ins = GetDeviceHealthData(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
    print(ins.run())
