import os
import sys
import datetime
import traceback

from SpecialTestSubject.GandalfLanguage.base.driver.web_driver.tac_get_device_health_data import \
    TacGetDeviceHealthData


class WebTacDriver(object):

    def __init__(self):
        self.tac_url = "https://admin.teams.microsoft.com/dashboard"
        self.tac_username = "benjaminye@jabralab.onmicrosoft.com"
        self.tac_password = "Dug81564"

    def get_device_health_data(self, device_display_id):
        tac_url = "https://admin.teams.microsoft.com/dashboard"
        tac_username = "benjaminye@jabralab.onmicrosoft.com"
        tac_password = "Dug81564!"
        # device_display_id="jabra-panacast1000 f72d38b8"
        return TacGetDeviceHealthData(tac_url, tac_username, tac_password, '"%s"' % device_display_id).run()