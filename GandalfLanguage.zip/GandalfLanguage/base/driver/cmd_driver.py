import json
import os
import subprocess
import time

from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger


class CmdDriver:
    '''
    if exec ADB command, need udid of Android Device
    if exec non-ADB command, no need udid
    '''
    def __init__(self,udid=None,):
        self.udid = udid


    '''
    Execute adb command in shell mode with root
    '''
    def exec_adb_shell_cmd(self, cmds, timeout=10):
        return self.__exec_adb_cmd(cmds, True,timeout)

    def exec_adb_cmd(self, cmds, timeout=10):
        return self.__exec_adb_cmd(cmds, False, timeout)

    '''
    cmds can be a list of command, or a string of command
    '''

    def __exec_adb_cmd(self, cmds, with_shell=False, timeout=10):
        if type(cmds) is list:
            commands = ' && '.join(cmds)
        else:
            commands = cmds

        if self.udid is None:
            command = f'adb {commands}'
        else:
            # root android if not root yet.
            if "root" not in os.popen(f"adb -s {self.udid} shell id").read():
                os.system(f"adb -s {self.udid} root")
                time.sleep(1)

            if with_shell:
                command = f'adb -s {self.udid} shell "{commands}"'
            else:
                command = f'adb -s {self.udid} {commands}'
        rst = subprocess.run(command, shell=True, capture_output=True, text=True, check=True, timeout=timeout).stdout
        return rst

    '''
    Exec a list of command, waiting output from last command for seconds
    Parameter:
        cmds: a list of command, can be a string or a []
        global_timeout: the time used to execute all the command in the list.
    Return:
        True: Last command output some string
        False: Last command output nothing
    '''

    def exec_adb_cmd_wait_output(self, cmds, global_timeout):
        t1 = time.time()
        while (time.time() - t1) <= global_timeout:
            reply = ""
            try:
                reply = self.__exec_adb_cmd(cmds, True)

            except:
                pass

            if reply != "":
                Logger.ins().file_logger().info(f"rst is {reply}")
                return
            time.sleep(1)
        raise TimeoutError


    def exec_pcos_cmd(self, cmds, timeout=10):
        """@Brief: Execute the CMD and return value
        @return: bool
        """
        if type(cmds) is list:
            for cmd in cmds:
                commands = cmd + "\n"
        else:
            commands = cmds

        process = subprocess.Popen("%s" % commands, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # 等待进程结束或超时
        output, stderr = process.communicate(timeout=timeout)
        return output