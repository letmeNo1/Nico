import sys,traceback,time

from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver
from SpecialTestSubject.GandalfLanguage.base.systemlogger import Logger


class WaitAndroidDeviceReady:
    def __init__(self, dut_pid, dut_vid, time_out, log_error):
        self.cmd_driver = CmdDriver()
        self.dut_pid = dut_pid.upper().replace('0X','')
        self.dut_vid = dut_vid.upper().replace('0X','')
        self.time_out = time_out
        self.log_error = str(log_error)
        # Define dut_pid2
        ##if pid1=3013 then pid2=3015
        ##if pid=3015 then pid2=3013
        ##if pid!=(3013,3015) then pid2=None
        self.dut_pid2 = None
        self.dut_pid2='3015' if self.dut_pid == '3013' else self.dut_pid2
        self.dut_pid2='3013' if self.dut_pid == '3015' else self.dut_pid2
    def run(self):
        rst = True
        stream2 = "None"
        try:
            t1 = time.time()
            while (time.time() - t1) <= int(self.time_out):
                stream = self.cmd_driver.exec_pcos_cmd("wmic path CIM_LogicalDevice get DeviceID|findstr %s| findstr %s"%(self.dut_vid, self.dut_pid))
                # Workaround Python PID change random by developer between 3013 and 3015
                if self.dut_pid2 != None:
                    stream2 = self.cmd_driver.exec_pcos_cmd("wmic path CIM_LogicalDevice get DeviceID|findstr %s| findstr %s"%(self.dut_vid, self.dut_pid2))
                    index2 = "VID_%s&PID_%s"%(self.dut_vid, self.dut_pid2)
                    Logger.ins().std_logger().info("---> [PY][WaitDeviceReady] expect_value2=%s, actual_value2=%s"%(index2, stream2.replace('\n','').replace(' ','')))
                index = "VID_%s&PID_%s"%(self.dut_vid, self.dut_pid)
                rst = (index in stream) or (index2 in stream2) if stream2 != "None" else (index in stream)
                if rst:
                    break
                time.sleep(1)
            Logger.ins().std_logger().info("---> [PY][WaitDeviceReady] rst=%s, expect_value=%s, actual_value=%s"%(rst, index, stream.replace('\n','').replace(' ','')))
        except:
            rst = False
            if self.log_error == 'True':
                Logger.ins().file_logger().error(traceback.format_exc())
        return rst

if __name__=="__main__":
    ins = WaitAndroidDeviceReady(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
    sys.exit(0) if ins.run() else sys.exit(1)