# Author: Felix He (GN Audio)
# Contact: fhe@jabra.com    

'''
OS: Windows 10.15
OS Resolution: 1366_768

Windows: Python running
'''
import json
import os

from SpecialTestSubject.GandalfLanguage.base.driver.pcos_driver.wait_android_device_connected import \
    WaitAndroidDeviceReady


class PcosDriver(object):

    def __init__(self, tr_name="PC_AG_Win"):
        Pcos = json.loads(os.getenv("SysInfo")).get(tr_name)

    def wait_android_device_connected(self,dut_pid, dut_vid, time_out, log_error=None):
        return WaitAndroidDeviceReady(dut_pid, dut_vid, time_out, log_error)
