import logging
import os

import lxml.etree as ET


class TranslationFileError(Exception):
    pass


def converting_strings(text, name):
    if text == "Support info":
        text = "Support"
    if text == "About devices":
        text = "Devices"
    # language = "zh-rCN"
    # language_xml_folder = r"C:\plt--vendor--jabra--packages--apps--jabra-meeting-android\app\src\main\res"
    language = os.getenv("Current_Language")
    language_xml_folder = os.getenv("Current_Languages_File_Path")
    if language == "zh":
        language = "zh-rCN"
    if language == "en-US":
        logging.info(f"Current is en_us: {text}")
        return text
    else:
        en_us_xml_file_path = language_xml_folder + r"\values\strings.xml"
        other_lang_xml_file_path = language_xml_folder + rf"\values-{language}\strings.xml"
        if not os.path.exists(other_lang_xml_file_path):
            raise TranslationFileError(f"{other_lang_xml_file_path} file does not exist, please check")
        tree = ET.parse(en_us_xml_file_path)
        en_us_root = tree.getroot()
        tree = ET.parse(other_lang_xml_file_path)
        other_lang_root = tree.getroot()
        if name is not None:
            print(other_lang_root.xpath(f".//string[@name='{name}']")[0])
            return other_lang_root.xpath(f".//string[@name='{name}']")[0].text
        else:
            for element in en_us_root.iter("string"):
                if element.text == text:
                    attribute_name = element.get("name")
                    if text == "Restart":
                        attribute_name = "tc_settings_menu_restart_restart_button"
                    if text == "Devices":
                        attribute_name = "tc_settings_menu_system_about"

                    try:
                        return other_lang_root.xpath(f".//string[@name='{attribute_name}']")[0].text
                    except IndexError:
                        os.environ["loc_error"] = str(os.getenv(
                            "loc_error")) + f",{language}-text {text} isn't translate string_name = {attribute_name})"
                        return text
            os.environ["loc_error"] = str(os.getenv(
                "loc_error")) + f",{language}-text {text} isn't translate string_name is not exitsts please check translate file)"

        return text


def collect_error_info():
    error_list = str(os.getenv("loc_error")).split(",")[1:]
    print("_________________error_____________________")
    for error in error_list:
        print(f"{error}")
