import os
import shutil
import lxml.etree as ET

from SpecialTestSubject.GandalfLanguage.base.driver.converting_strings import converting_strings


class LocWebDriver:
    def __init__(self,browser):
        self.browser = browser

    '''
    This method is only used for localization testing
    '''
    def scroll_to_see(self, ele):
        return self.browser.ele(ele).scroll.to_see()

    def scroll_to_bottom(self, ele):
        return self.browser.ele(ele).scroll.to_bottom()

    def loc_snapshot(self, step, module):
        current_time = os.getenv('Current_Time')
        language = os.getenv("Current_Language")
        currently_running_function = os.getenv("currently_running_function")
        path = os.getcwd() + f"\\WebScreenShot\\{currently_running_function}_{current_time}\\{language}\\"
        if not os.path.exists(path):
            os.system(f"mkdir {path}")
        os.system(f'''del {path}\\{language}_{module}_{step}.png''')
        self.browser.get_screenshot(path + f"{language}_{module}_{step}.png")

    def find_element_by_loc_text(self, query, name=None, timeout=3):
        translated_content = converting_strings(query, name)
        print(translated_content)
        return self.browser.ele(f"text:{translated_content}", timeout=timeout)

    def find_element_by_name_and_click(self, name,index =0):
        return self.browser.run_js(f'document.getElementsByName("{name}")[{index}].click()')

    def find_element(self, query,timeout=3):
        return self.browser.ele(query, timeout=timeout)

    def refresh_page(self):
        return self.browser.refresh()

    '''
        This method is only used for localization testing
        '''

    def __check_text(self, root, target_value):
        stack = [root]

        while stack:
            element = stack.pop()

            # 判断当前元素的text是否包含目标值
            if element.text and target_value in element.text:
                return True

            # 将子元素入栈，继续遍历
            stack.extend(element)
        return False

    def __check_text_in_file(self,file_path, text_to_find):
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if text_to_find in line:
                    return True
        return False

    def check_text_in_current_page(self,step, module):
        current_time = os.getenv('Current_Time')
        language = os.getenv("Current_Language")
        currently_running_function = os.getenv("currently_running_function")
        path = os.getcwd() + f"\\WebScreenShot\\{currently_running_function}_{current_time}\\{language}\\"
        error_file_path = path+"error.txt"
        if not os.path.exists(path):
            os.system(f"mkdir {path}")
        if not os.path.exists(error_file_path):
            # 文件不存在，使用 open 函数创建新文件
            with open(path+"error.txt", "w", encoding="utf-8"):
                pass
        if language != "en-US":
            language_xml_folder = os.getenv("Current_Languages_File_Path")
            other_lang_xml_file_path = language_xml_folder + rf"\values-{language}\strings.xml"
            tree = ET.parse(other_lang_xml_file_path)
            other_lang_root = tree.getroot()
            p_list = self.browser.s_eles('tag:p')
            span_list = self.browser.s_eles('tag:span')
            h1_list = self.browser.s_eles('tag:h1')
            h3_list = self.browser.s_eles('tag:h3')
            li_list = self.browser.s_eles('tag:li')
            button_list = self.browser.s_eles('tag:button')
            div_list = self.browser.s_eles('tag:div')
            all_eles = p_list + span_list + h1_list + h3_list + li_list + button_list + div_list
            for ele in all_eles:
                if ele.text != "" and ele.tag != "" and len(ele.children()) == 0:
                    if not self.__check_text(other_lang_root, ele.text):
                        string_to_write = f"{language}_{module}_{step}.png :tag = {ele.tag} text = {ele.text} isn't translate"
                        if not self.__check_text_in_file(error_file_path,f"tag = {ele.tag} text = {ele.text}"):
                            with open(error_file_path, 'a',encoding='utf-8') as file:  # 将 "your_file.txt" 替换为您要写入的文本文件的名称
                                file.write(string_to_write+"\n")
