import re
import time

from DrissionPage import ChromiumPage
from DrissionPage.mixpage.mix_page import MixPage
from DrissionPage.easy_set import set_paths
from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver

languages_dict = {"zh": 0, "cs": 1, "da": 2, "nl": 3, "en-US": 4, "fi": 5, "fr": 6, "de": 7, "hu": 8, "it": 9,
                  "nb": 10,
                  "pl": 11, "ru": 12, "es": 13, "sv": 14, "tr": 15, "ja": 16}

def get_web_ui_url(udid):
    cmd_driver = CmdDriver(udid)
    rst = cmd_driver.exec_adb_shell_cmd("ifconfig | grep 'inet addr'").lstrip()
    pattern = r'inet addr:(10\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    matches = re.findall(pattern, rst)

    # 提取到的IP地址列表
    for ip in matches:
        return ip


def change_language(language, udid, function="web", close_page=False):
    password = udid[-6:]
    if function == "web" or function =="tc_installation":
        set_paths("./chromedriver.exe")
        page = ChromiumPage()
        url = get_web_ui_url(udid)

        page.get(f"http://{url}")
        try:
            page.ele("@id=details-button", timeout=2).click()
            page.ele("@id=proceed-link").click()
        except:
            pass
        page.ele("@name=username",timeout=30).input("admin")
        page.ele("@name=password").input(password)
        page.ele("@type=submit").click()

        page.ele("@href=#/general/region", timeout=10).click()
        page.ele('xpath://*[@id="root"]/div/div[2]/form/div[3]/div/div[1]/div[2]/label/div/div/input').click()
        page.scroll.to_see(f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language)+1}]')
        page.ele(f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language)+1}]').click()
        page.ele("@type=submit").click()
        if close_page:
            cmd_driver = CmdDriver()
            cmd_driver.exec_pcos_cmd("taskkill /IM chrome.exe")
    elif function == "vb_installation":
        set_paths("./chromedriver.exe")
        page = ChromiumPage()
        url = get_web_ui_url(udid)
        print(url)
        page.get(f"http://{url}")
        try:
            page.ele("@id=details-button", timeout=2).click()
            page.ele("@id=proceed-link").click()
        except:
            pass
        page.ele("@name=username", timeout=5).input("admin")
        page.ele("@name=password", timeout=5).input(password)
        page.ele("@type=submit").click()
        page.scroll.to_see(
            f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language) + 1}]')
        page(f'xpath://*[@id="root"]/div[2]/div/form/div/div/label[{languages_dict.get(language) + 1}]').click()
        page.ele("@type=submit").click()
    elif function == "jabra_meeting":
        if language == "en-US":
            language = "en"
        cmd_driver = CmdDriver(udid)
        clear_pre_pair_cmds = ["cd system/vendor/bin", f"./jose_service_controller system --set-locale {language}"]
        cmd_driver.exec_adb_shell_cmd(clear_pre_pair_cmds), "#pre_condition clear pre-pair serial number fail"
