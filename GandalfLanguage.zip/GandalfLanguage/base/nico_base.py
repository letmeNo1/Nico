import os

from nico.get_uiautomator_xml import get_root_node
from nico.nico import AdbAutoNico
from nico.utils import Utils

from SpecialTestSubject.GandalfLanguage.base.driver.cmd_driver import CmdDriver


class TranslationFileError(Exception):
    pass


class NicoBase(Utils):
    def __init__(self, udid):
        super().__init__(udid)
        self.udid = udid
        self.env = "en_1920_1080"
        self.nico = AdbAutoNico(udid)
        self.cmd_driver = CmdDriver(self.udid)

    def scroll_to_find_element(self, scroll_time=10, target_area=None, **query):
        x = int(self.get_screen_size()[0] / 2)
        y1 = int(self.get_screen_size()[1] / 4)
        y2 = int(self.get_screen_size()[1] / 2)
        if target_area is not None:
            x = int(self.get_screen_size()[0] * target_area.get_position()[0])
            y1 = int((self.get_screen_size()[1] * target_area.get_position()[1]) / 4)
            y2 = int((self.get_screen_size()[1] * target_area.get_position()[1]) / 2)
        for i in range(int(scroll_time)):
            print("finding")
            rst = self.nico(**query).exists()
            if rst:
                print("!!!!!!!!!!!found!")
                return self.nico(**query,)

            else:
                print("Couldn't found! try again")
                self.cmd_driver.exec_adb_shell_cmd(f"input swipe {x} {y2} {x} {y1}")
        return None

    def take_snapshot(self, name, path):
        if not os.path.exists(path):
            os.makedirs(path)
        self.snapshot(name, path)

    def get_root_node(self):
        return get_root_node(self.udid)