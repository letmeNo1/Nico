import datetime
import os
import time
import traceback

import numpy as np


import cv2
import pyautogui
import threading

class PCRecording:
    def __init__(self,func_name):
        # 获取屏幕的宽度和高度
        self.is_running = None
        self.thread = None
        self.screen_width, self.screen_height = pyautogui.size()
        print(self.screen_width)

        current_time = os.getenv('Current_Time')
        language = os.getenv("Current_Language")
        currently_running_function = os.getenv("currently_running_function")
        log_folder_path = os.getcwd() + f"\\WebScreenShot\\{currently_running_function}_{current_time}\\{language}"
        if not os.path.exists(log_folder_path):
            os.system(f"mkdir {log_folder_path}")
        func_name = func_name + "___"
        self.out = None
        self.log_folder_path = log_folder_path
        filename = datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + func_name
        self.filename = filename



    def start(self):
        # 启动线程
        # 创建VideoWriter对象
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        self.out = cv2.VideoWriter(f"{self.log_folder_path}\\{self.filename}.avi", fourcc, 20.0,
                                   (self.screen_width, self.screen_height))
        # 创建线程
        self.thread = threading.Thread(target=self.record_screen)
        self.thread.start()

    def stop(self):
        # 停止线程
        self.is_running = False
        self.thread.join()

        # 释放资源
        self.out.release()
        cv2.destroyAllWindows()

    def record_screen(self):
        # 标记线程是否正在运行
        self.is_running = True

        # 捕捉屏幕
        while self.is_running:
            # 获取屏幕截图
            img = cv2.cvtColor(np.array(pyautogui.screenshot()), cv2.COLOR_BGR2RGB)

            # 写入视频文件
            self.out.write(img)

class AndroidRecording:
    def __init__(self, udid):
        self.udid = udid

    def android_start_recording(self):
        try:
            currently_running_function = os.getenv("currently_running_function")
            print(f"---> [Recording][start_recording] {currently_running_function}")
            os.popen("adb -s %s shell screenrecord --time-limit 180 /sdcard/demorecord.mp4 &" % self.udid)
        except:
            print(traceback.format_exc())

    def android_stop_recording(self, func_name):
        try:
            current_time = os.getenv('Current_Time')
            language = os.getenv("Current_Language")
            currently_running_function = os.getenv("currently_running_function")
            log_folder_path = os.getcwd() + f"\\ScreenShot\\{currently_running_function}_{current_time}\\{language}\\"
            func_name = func_name + "___"

            filename = datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + func_name + ".mp4"
            screenrecord_pid_info = os.popen('''adb -s %s shell "ps -ef | grep screenrecord"''' % self.udid).read()
            if screenrecord_pid_info != "":
                screenrecord_pid = screenrecord_pid_info.split()[1]
                # Logger.ins().std_logger().info(r"---> [TeamsCommon][stop_recording] Query recorder pid %s" % (screenrecord_pid))
                os.system("adb -s %s shell kill -s 2 %s" % (self.udid, screenrecord_pid))
                time.sleep(1)
            cmd = fr'adb -s {self.udid} pull /sdcard/demorecord.mp4 "{log_folder_path}\{filename}"'
            ret = os.popen(cmd).read()
            print(fr"---> [Recording][stop_recording] pull ret={ret}, file_name = {log_folder_path}\{filename}")
        except:
            print(traceback.format_exc())