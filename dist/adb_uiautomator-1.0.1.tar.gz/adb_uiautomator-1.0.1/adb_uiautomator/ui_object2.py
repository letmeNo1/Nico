from adb_uiautomator.nico import AdbAutoNico


aa = AdbAutoNico("514f465834593398",wait_idle=1010)
# aa(text ="Next").wait_for_appearance()
aa(id ="com.sec.android.app.clockpackage:id/stopwatch_timeview",force_reload=True).wait_for_appearance()
print(aa(id ="com.sec.android.app.clockpackage:id/stopwatch_timeview",class_name="android.widget.LinearLayout",force_reload=True).content_desc)