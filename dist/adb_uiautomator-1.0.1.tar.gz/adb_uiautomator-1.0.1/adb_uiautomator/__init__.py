from adb_uiautomator.utils import Utils

a = Utils("514f465834593398")
a.unlock()