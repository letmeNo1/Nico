# Nico
A framework for building Android automation based on adb commands

Readme 正在编写中，调用请参考 test.py 
