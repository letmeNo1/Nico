# Nico
A framework for building Android automation based on adb commands
